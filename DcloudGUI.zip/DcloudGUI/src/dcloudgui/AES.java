/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package dcloudgui;

import java.security.Key;
import java.util.logging.Level;
import java.util.logging.Logger;
import javax.crypto.Cipher;
import javax .crypto.spec.SecretKeySpec;
import java.util.Base64.Encoder;
import java.util.Base64.Decoder;
/**
 *
 * @author sahil26
 */
public class AES {
        private static final String ALGO = "AES";
    private final byte[] keyValue;

    public AES(String key) {
        keyValue = key.getBytes();
    }

    public String encrypt(String Data) throws Exception {
        Key key = generateKey();
        Cipher c = Cipher.getInstance(ALGO);
        c.init(Cipher.ENCRYPT_MODE, key);
        byte[] encVal = c.doFinal(Data.getBytes("UTF-8"));
        //String encryptedValue = new BASE64Encoder().encode(encVal);
        String encryptedValue = java.util.Base64.getEncoder().encodeToString(encVal);
        return encryptedValue;
    }

    public String decrypt(String encryptedData) throws Exception {
        Key key = generateKey();
        Cipher c = Cipher.getInstance(ALGO);
        c.init(Cipher.DECRYPT_MODE, key);
        //byte[] decodedValue = new BASE64Decoder().decodeBuffer(encryptedData);
        byte[] decodedValue = java.util.Base64.getDecoder().decode(encryptedData);
        byte[] decValue = c.doFinal(decodedValue);
        String decryptedValue = new String(decValue);
        return decryptedValue;
    }

    private Key generateKey() throws Exception {
        Key key = new SecretKeySpec(keyValue, ALGO);
        return key;
    }

    /*public static void main(String args[]) {
        try {
            AES aes = new AES("Iv39eptIvuhaqqs0");
            String encdata = aes.encrypt("Vinayak");
            System.out.println("Encrypted Data : " + encdata);
            String decdata = aes.decrypt(encdata);
            System.out.println("Decrypted Data : " + decdata);
        }
        catch (Exception ex) {
            Logger.getLogger(AES.class.getName()).log(Level.SEVERE, null, ex);
        }
    }*/
}
