package dcloudgui;

import java.awt.Desktop;
import java.io.File;
import java.io.IOException;
import java.util.logging.Level;
import java.util.logging.Logger;
import javafx.application.Application;
import javafx.event.ActionEvent;
import javafx.event.EventHandler;
import javafx.geometry.HPos;
import javafx.geometry.Insets;
import javafx.geometry.Pos;
import javafx.scene.Scene;
import javafx.scene.control.*;
import javafx.scene.layout.*;
import javafx.scene.text.Font;
import javafx.scene.text.FontWeight;
import javafx.scene.text.Text;
import javafx.stage.DirectoryChooser;
import javafx.stage.FileChooser;
import javafx.stage.Stage;
import javafx.stage.Window;

public class DcloudGUI extends Application {
        Stage window;
        private Desktop desktop = Desktop.getDesktop();
       /* public static void main1() {
        launch();
    }*/
    @Override
    public void start(Stage primaryStage) throws Exception {
         window = primaryStage;
         window.setTitle("DcloudGUI");
         primaryStage.setMaximized(true);
         
         GridPane grid = new GridPane();
         grid.setAlignment(Pos.CENTER);
         grid.setVgap(10);
         grid.setHgap(10);
         grid.setPadding(new Insets(10));
         
         Text welcomeTxt = new Text("Upload");
         welcomeTxt.setFont(Font.font("Tahoma",FontWeight.LIGHT , 25));
         grid.add(welcomeTxt, 1, 0);
         
         Label lblFile = new Label("FilePath* :");
         grid.add(lblFile, 0, 1);
         
         TextField txtFile = new TextField();
         txtFile.setPromptText("Path of File..!!");
         grid.add(txtFile,1,1);
         
         final FileChooser fileChooser = new FileChooser();
         final Button openButton = new Button("Browse");
         grid.add(openButton,2,1);
         openButton.setOnAction(
                new EventHandler<ActionEvent>() {
                @Override
                public void handle(final ActionEvent e) {
                    File file = fileChooser.showOpenDialog(primaryStage);
                    if (file != null) {
                        //openFile(file);
                        txtFile.clear();
                        txtFile.appendText(file.getAbsolutePath());
                    }
                }
            }
         );
         
         Label lblPassword = new Label("Encryption Key* :");
         grid.add(lblPassword, 0, 2);
         
         PasswordField pwBox = new PasswordField();
         pwBox.setPromptText("16 Digit Key");
         grid.add(pwBox,1,2);
         
         Label lblKey = new Label("KeyPath* :");
         grid.add(lblKey, 0,3 );
         
         TextField txtKey = new TextField();
         txtKey.setPromptText("Path of Key..!!");
         grid.add(txtKey,1,3);
         
         final FileChooser keyChooser = new FileChooser();
         final Button Keybtn = new Button("Browse");
         grid.add(Keybtn,2,3);
         Keybtn.setOnAction(
                new EventHandler<ActionEvent>() {
                @Override
                public void handle(final ActionEvent e) {
                   /* File file = fileChooser.showOpenDialog(primaryStage);
                    if (file != null) {
                        //openFile(file);
                        txtKey.appendText(file.getAbsolutePath());
                    }*/
                    DirectoryChooser directoryChooser = new DirectoryChooser();
                    File selectedDirectory = directoryChooser.showDialog(primaryStage);

                    if(selectedDirectory != null){
                        txtKey.clear();
                    txtKey.appendText(selectedDirectory.getAbsolutePath());
                    }
                }
            }
         );
         
         final Label label = new Label();
         grid.add(label,0,5);
         
         Button loginbtn = new Button("Submit");
         grid.add(loginbtn, 1, 4);
         loginbtn.setOnAction(e->{
             //System.out.println("Path :"+txtFile.getText());
             //System.out.println("Key :"+pwBox.getText());
             if(txtFile.getText()!=null && !txtFile.getText().isEmpty()){
                 if(pwBox.getText()!=null && !pwBox.getText().isEmpty()){
                     if(pwBox.getText().length()==16){
                         if(txtKey.getText()!=null && !txtKey.getText().isEmpty()){
                         label.setText("Thanks For the Information..!!");
                         System.out.println("Path :"+txtFile.getText());
                         System.out.println("Key :"+pwBox.getText());
                         System.out.println("KeyStorage Path :"+txtKey.getText());
                         storefile s = new storefile(txtFile.getText(),pwBox.getText(),txtKey.getText());
                             try {
                                 s.insert();
                             } catch (IOException ex) {
                                 Logger.getLogger(DcloudGUI.class.getName()).log(Level.SEVERE, null, ex);
                             }
                         }
                         else
                         {
                             label.setText("Please Enter Path For Key Storage..!!");
                         }
                     }
                     else
                     {
                         label.setText("Plese Enter 16 digits For Encryption Key.!!");
                     }
                 }
                 else
                 {
                     label.setText("Please Enter Key..!!");
                 }
             }
             else
             {
                 label.setText("Please Enter File Path..!!");
             }
         });
         
         Button clearbtn = new Button("clear");
         grid.add(clearbtn,2,4);
         clearbtn.setOnAction(e->{
             label.setText(null);
             txtFile.clear();
             pwBox.clear();
             txtKey.clear();
         });
         
         Scene scene = new Scene(grid, 500, 500);
         window.setScene(scene);
         window.show();
    } 
        private void openFile(File file) {
        try {
            desktop.open(file);
        } catch (IOException ex) {
            Logger.getLogger(DcloudGUI.class.getName()).log(
                Level.SEVERE, null, ex
            );
        }
    }

}