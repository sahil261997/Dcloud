/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package dcloudgui;

import java.io.*;
import java.util.Scanner;
/**
 *
 * @author sahil26
 */
public class downloadfile {
    Scanner scanner = new Scanner(System.in);
    String kp,path;
    downloadfile(String keyPath,String p){
        kp = keyPath;
        path = p;
    }
    void retrieve() throws FileNotFoundException, IOException, Exception{
        System.out.println("Enter The Encryption Key to Decrypt :");
        String k = kp;
        FileReader fr = new FileReader(k);
        BufferedReader br = new BufferedReader(fr);
        String Filename = br.readLine();
        String key1 = br.readLine();
        AES aesD = new AES(key1);
        System.out.println("Decrypting the Files..!!");
        String nof = br.readLine();
        join j = new join(Integer.parseInt(nof),aesD);
        join.data(Filename,br,path);
        br.close();
        fr.close();
    }
}
