/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package dcloudgui;

/**
 *
 * @author sahil26
 */
/*public class join {
    
}*/


import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileWriter;
import java.io.IOException;
import java.io.InputStreamReader;
import java.util.logging.Level;
import java.util.logging.Logger;
 
public class join {
        static int nof;
        static AES aesD;
        join(int n,AES aes){
            nof = n;
            aesD = aes;
        }
 
    /**
     *
     * @param filename
     * @param br
     * @throws java.lang.Exception
     */
    public static void data(String filename,BufferedReader br,String p) throws Exception {
		//String sourceFile1Path = "/home/programcreek/Desktop/s1";
		//String sourceFile2Path = "/home/programcreek/Desktop/s2";
 
		String mergedFilePath = "/final.txt";
 
		File[] files = new File[nof];
		//files[0] = new File(sourceFile1Path);
		//files[1] = new File(sourceFile2Path);
                /*for(int i=0 ; i<nof ; i++){
                    files[i] = new File((i+1)+".txt");
                }*/
                String path;
                int i=0;
                while((path = br.readLine())!=null && i<nof){
                    files[i] = new File(path);
                    i++;
                }
 
		File mergedFile = new File(p+mergedFilePath);
 
		mergeFiles(files, mergedFile);
	}
 
	public static void mergeFiles(File[] files, File mergedFile) throws Exception {
 
		FileWriter fstream = null;
		BufferedWriter out = null;
		try {
			fstream = new FileWriter(mergedFile, true);
			 out = new BufferedWriter(fstream);
		} catch (IOException e1) {
			e1.printStackTrace();
		}
 
		for (File f : files) {
			System.out.println("merging: " + f.getName());
			FileInputStream fis;
			try {
				fis = new FileInputStream(f);
                            try (BufferedReader in = new BufferedReader(new InputStreamReader(fis))) {
                                String aLine;
                                while ((aLine = in.readLine()) != null) {
                                    try {
                                        aLine = mainGUI.dec(aLine, aesD);
                                    } catch (Exception ex) {
                                        Logger.getLogger(join.class.getName()).log(Level.SEVERE, null, ex);
                                    }
                                    out.write(aLine);
                                    out.newLine();
                                }
                            }
			} catch (IOException e) {
				e.printStackTrace();
			}
		}
 
		try {
			out.close();
		} catch (IOException e) {
			e.printStackTrace();
		}
 
	}
}