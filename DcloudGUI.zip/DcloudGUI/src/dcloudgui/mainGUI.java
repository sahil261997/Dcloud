/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package dcloudgui;

import java.util.logging.Level;
import java.util.logging.Logger;
import javafx.application.Application;
import javafx.event.ActionEvent;
import javafx.event.EventHandler;
import javafx.geometry.Insets;
import javafx.geometry.Pos;
import javafx.scene.Scene;
import javafx.scene.control.Button;
import javafx.scene.layout.GridPane;
import javafx.scene.text.Font;
import javafx.scene.text.FontWeight;
import javafx.scene.text.Text;
import javafx.stage.Stage;

/**
 *
 * @author sahil26
 */
public class mainGUI extends Application {
    Stage window;
    public static void main(String[] args){
        launch(args);
    }
    @Override
    public void start(Stage primaryStage) throws Exception {
        //throw new UnsupportedOperationException("Not supported yet."); //To change body of generated methods, choose Tools | Templates.
        window = primaryStage;
        window.setTitle("DcloudGUI");
        //primaryStage.setMaximized(true);
        
         GridPane grid = new GridPane();
         grid.setAlignment(Pos.CENTER);
         grid.setVgap(10);
         grid.setHgap(10);
         grid.setPadding(new Insets(10));
         
         Text welcomeTxt = new Text("Dcloud");
         welcomeTxt.setFont(Font.font("Tahoma",FontWeight.LIGHT , 25));
         grid.add(welcomeTxt, 1, 0);  
         
         final Button upbtn = new Button("UploadFile");
         grid.add(upbtn,0,2);
         
         DcloudGUI d = new DcloudGUI();
         upbtn.setOnAction(
                new EventHandler<ActionEvent>() {
                @Override
                public void handle(final ActionEvent e) {
                    try {
                        d.start(primaryStage);
                    } catch (Exception ex) {
                        Logger.getLogger(mainGUI.class.getName()).log(Level.SEVERE, null, ex);
                    }
                }
            }
         );
         
         Retrieve r = new Retrieve();
         
         final Button downbtn = new Button("DownloadFile");
         grid.add(downbtn,2,2);
         
                  downbtn.setOnAction(
                new EventHandler<ActionEvent>() {
                @Override
                public void handle(final ActionEvent e) {
                    try {
                        r.start(primaryStage);
                    } catch (Exception ex) {
                        Logger.getLogger(mainGUI.class.getName()).log(Level.SEVERE, null, ex);
                    }
                }
            }
         );
         
         Scene scene = new Scene(grid, 500, 500);
         window.setScene(scene);
         window.show();
    }
    
    static String enc(String str,AES aes) throws Exception{
    str = aes.encrypt(str);
    return str;
    }
    static String dec(String str,AES aes) throws Exception{
        str = aes.decrypt(str);
        return str;
    }
    
}
