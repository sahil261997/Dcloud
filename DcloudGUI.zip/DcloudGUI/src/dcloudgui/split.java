/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package dcloudgui;

import java.io.*;
import java.nio.charset.StandardCharsets;
import java.security.MessageDigest;
import java.util.Base64;
import java.util.Scanner;
/**
 *
 * @author sahil26
 */
public class split{
            // read file and get no. of files to be generated
            //String inputfile = args[0];

            // No. of lines to be split and saved in each
            double nol = 2.0;
            String inputfile ;
            Scanner scanner;
            String k;
            AES aes;
            FileWriter fw;
            split(String file , AES a,FileWriter f){
                inputfile = file;
                aes = a;
                fw = f;
            };

            public void process(BufferedWriter bw) throws IOException{
                try {
            int count = 0;
            File file = new File(inputfile);
            scanner = new Scanner(file);
            
            while(scanner.hasNextLine())
            {
                //if(!scanner.nextLine().equals("")){}
                scanner.nextLine();
                count++;
            }

            // display no. of lines in the input file.
            if(count%2 != 0){
                count++;
                FileWriter f = new FileWriter(inputfile,true);
                BufferedWriter b = new BufferedWriter(f);
                //f.append("");
                b.newLine();
                b.close();
                f.close();
            }
            System.out.println("Lines in the file: " + count);

            double temp = (count / nol);
            int temp1 = (int) temp;
            int nof = 0;
            if (temp1 == temp) {
                nof = temp1;
            } else {
                nof = temp1 + 1;
            }
            System.out.println("No. of files to be generated :" + nof);
            bw.write(Integer.toString(nof));
            bw.newLine();

            // splitting of file into multiple files
            FileInputStream fstream = new FileInputStream(inputfile);
                    try (DataInputStream in = new DataInputStream(fstream)) {
                        BufferedReader br = new BufferedReader(new InputStreamReader(in));
                        String strLine;
                        
                        MessageDigest digest = MessageDigest.getInstance("SHA-256");
                        
                        for (int j = 1; j <= nof; j++) {
                            
                            // location of new file
                            String fn = inputfile+"/"+j;
                            byte[] hash = digest.digest(fn.getBytes(StandardCharsets.UTF_8));
                            String encoded = Base64.getEncoder().encodeToString(hash);
                            //String fname = fn.hashCode();
                            /*MessageDigest digest = MessageDigest.getInstance("SHA-256");
byte[] hash = digest.digest(text.getBytes(StandardCharsets.UTF_8));
String encoded = Base64.getEncoder().encodeToString(hash);*/
                            String path = "Server"+j+"/"+encoded;
                            File f = new File(path);
                            if(!f.exists()){
                                f.getParentFile().mkdirs();
                                f.createNewFile();
                            }
                            FileWriter fstream1 = new FileWriter(f);
                            try (BufferedWriter out = new BufferedWriter(fstream1)) {
                                for (int i = 1; i <= nol; i++) {
                                    strLine = br.readLine();
                                    //if(!strLine.equals("")){
                                    strLine = mainGUI.enc(strLine,aes);
                                    //}
                                    if (strLine != null) {
                                        out.write(strLine);
                                        if (i != nol) {
                                            out.newLine();
                                        }
                                    }
                                }
                              
                            }
                            String s = f.getAbsolutePath();
                            bw.write(s);
                            bw.newLine();
                           
                        }  
                    }
            scanner.close();
        } 
        catch (Exception e) {
            System.err.println("Error: " + e.getMessage());
        }
    }
}

    
