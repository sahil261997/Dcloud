/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package dcloudgui;

import java.io.*;
import java.util.Scanner;
/**
 *
 * @author sahil26
 */
public class storefile {
    Scanner scanner = new Scanner(System.in);
    String path;
    String Key;
    String keyPath;
    storefile(String p,String k,String kp){
        path = p;
        Key = k;
        keyPath = kp;
    }
    void insert() throws IOException{
        ///System.out.print("Enter The Name of File : ");
            String fname = path;
        try (FileWriter fw = new FileWriter(keyPath+"/Key.txt");
            BufferedWriter bw = new BufferedWriter(fw)) {
            bw.write(fname);
            bw.newLine();
           // System.out.print("Enter The Encryption Key (16 Letters(1,a,@,#..): ");
            String key = Key;
            /*while((key = scanner.nextLine()).length() != 16)
            {
                System.out.print("Please Enter Only 16 Characters : ");
            }*/
            bw.write(key);
            bw.newLine();
            AES aesE = new AES(key);
            System.out.println("Encrypting the Data...!!");
            split sp = new split(fname,aesE,fw);
            sp.process(bw);
            System.out.println("Splitting the files..!!");
            System.out.println(fname +" " + key);
        }
    }
}
